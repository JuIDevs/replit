# Guía de Administración - Distribuidora Renata

Esta guía explica cómo administrar el sitio web de Distribuidora Renata, incluyendo cómo añadir productos, categorías y gestionar el contenido.

## Configuración Inicial

### 1. Crear una Cuenta y Convertirse en Administrador

1. Visita el sitio web y haz clic en "Acceso" en el menú de navegación
2. Regístrate con un nombre de usuario y contraseña
3. Para convertir tu cuenta en administrador, ejecuta este comando en la terminal:
   ```
   node make-admin.js TU_NOMBRE_DE_USUARIO
   ```
4. Una vez que seas administrador, el sistema automáticamente añadirá algunos productos y categorías de ejemplo

### 2. Acceder al Panel de Administración

Una vez que tengas privilegios de administrador:

1. Inicia sesión con tu cuenta
2. Visita `/admin` en tu navegador o utiliza los enlaces que aparecerán en el menú cuando estés conectado

## Gestión de Productos

### Añadir un Nuevo Producto

1. Ve a "Administración" → "Productos"
2. Haz clic en el botón "Nuevo Producto"
3. Completa el formulario con la siguiente información:
   - Nombre del producto
   - Descripción
   - Precio
   - URL de la imagen (puedes usar servicios como Unsplash o tu propio hosting de imágenes)
   - Categoría (selecciona de la lista desplegable)
   - Stock disponible
   - Destacado (marcar si quieres que aparezca en la página principal)
   - Etiqueta (opcional: "NUEVO", "OFERTA", etc.)
4. Haz clic en "Guardar Producto"

### Editar un Producto Existente

1. Ve a "Administración" → "Productos"
2. Encuentra el producto en la tabla y haz clic en el botón "Editar"
3. Modifica los campos necesarios
4. Haz clic en "Actualizar Producto"

### Eliminar un Producto

1. Ve a "Administración" → "Productos"
2. Encuentra el producto en la tabla y haz clic en el botón "Eliminar"
3. Confirma la eliminación cuando se te solicite

## Gestión de Categorías

Las categorías se pueden gestionar desde el panel de administración. 

### Añadir una Nueva Categoría

1. Ve a "Administración" → "Dashboard" 
2. Haz clic en "Gestionar Categorías"
3. Utiliza el formulario para añadir una nueva categoría con:
   - Nombre de la categoría
   - Descripción (opcional)
   - URL de la imagen (opcional)
4. Haz clic en "Guardar Categoría"

## Consejos Adicionales

- **Imágenes**: Para obtener mejores resultados, utiliza imágenes en formato 16:9 o cuadrado
- **Productos Destacados**: Los productos marcados como "destacados" aparecerán en la sección "Productos Destacados" de la página principal
- **Datos de Prueba**: Si necesitas reiniciar con datos de ejemplo, puedes ejecutar:
  ```
  node seed-data.js
  ```
- **Resolución de Problemas**: Si encuentras algún problema, revisa la consola del navegador para ver si hay errores

## Soporte

Si necesitas ayuda adicional, contacta al desarrollador a través de la información de contacto proporcionada.
