import React from 'react';
import { Link } from 'wouter';
import { Button } from '@/components/ui/button';

const Hero = () => {
  return (
    <section className="relative bg-renata-black">
      <div className="container mx-auto px-4 py-16 md:py-24">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
          <div>
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-inter font-bold text-white mb-4">
              Calidad y frescura <span className="text-renata-yellow">garantizada</span>
            </h1>
            <p className="text-lg text-gray-300 mb-8">
              Distribuidora Renata, tu aliado confiable en productos alimenticios de primera calidad para tu negocio.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Link href="/products">
                <Button size="lg" className="bg-renata-yellow hover:bg-yellow-500 text-renata-black font-bold transition-colors">
                  Ver productos
                </Button>
              </Link>
              <Link href="/contact">
                <Button size="lg" variant="outline" className="bg-white text-black border-white hover:text-white hover:bg-white/10 focus:ring-2 focus:ring-white/30">
                  Contactar ahora
                </Button>
              </Link>
            </div>
          </div>
          
          <div className="relative h-64 md:h-96 overflow-hidden rounded-lg shadow-xl">
            <img             src="https://lh3.googleusercontent.com/p/AF1QipP3MiEU3cMHZcjsXJXNefofP4orfyZZEDd9mLlA=s680-w680-h510-rw" 
              alt="Distribución de alimentos" 
              className="w-full h-full object-contain object-center border-4 border-renata-yellow"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
            <div className="absolute bottom-4 left-4 right-4">
              <div className="bg-white/80 backdrop-blur-sm p-3 rounded-md">
                <p className="font-medium text-renata-black text-center">
                  Distribución de alimentos frescos y de alta calidad para el sector mayorista y minorista.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
