import React from 'react';
import ContactForm from '@/components/shared/contact-form';
import { MapPin, Phone, Mail, Clock } from 'lucide-react';

const ContactPage = () => {
  return (
    <section id="contact" className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-inter font-bold text-renata-black text-center mb-2">Contáctanos</h2>
        <p className="text-renata-dark-gray text-center mb-12">Estamos aquí para ayudarte con tus necesidades de distribución</p>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Contact Form */}
          <div className="bg-renata-gray p-8 rounded-lg shadow-md">
            <h3 className="text-2xl font-inter font-bold text-renata-black mb-6">Envíanos un mensaje</h3>
            <ContactForm />
          </div>

          {/* Contact Information */}
          <div>
            <h3 className="text-2xl font-inter font-bold text-renata-black mb-6">Información de contacto</h3>
            <div className="space-y-6">
              
              <div className="flex items-start">
                <div className="bg-renata-yellow rounded-full w-10 h-10 flex items-center justify-center mr-4 mt-1 flex-shrink-0">
                  <Phone className="text-renata-black h-5 w-5" />
                </div>
                <div>
                  <h4 className="font-bold text-black text-lg mb-1">Teléfonos</h4>
                  <p className="text-black"><span className="text-green-600">+54 9 351 274-2582 (WhatsApp)</span><br />+54 9 351 XXX-XXXX</p>
                </div>
              </div>
              <div className="flex items-start">
                <div className="bg-renata-yellow rounded-full w-10 h-10 flex items-center justify-center mr-4 mt-1 flex-shrink-0">
                  <Mail className="text-renata-black h-5 w-5" />
                </div>
                <div>
                  <h4 className="font-bold text-black text-lg mb-1">Correo electrónico</h4>
                  <p className="text-renata-dark-gray">ventas@distribuidorarenata.com<br />info@distribuidorarenata.com</p>
                </div>
              </div>
              <div className="flex items-start">
                <div className="bg-renata-yellow rounded-full w-10 h-10 flex items-center justify-center mr-4 mt-1 flex-shrink-0">
                  <Clock className="text-renata-black h-5 w-5" />
                </div>
                <div>
                  <h4 className="font-bold text-black text-lg mb-1">Horario de atención</h4>
                  <p className="text-renata-dark-gray"><u>Lunes a Viernes:</u> 8:30 - 13:00 y 17:00 - 20:00<br /><u>Sábados:</u> 8:30 - 13:00</p>
                </div>
              </div>
            </div>
            <div className="flex items-start mt-4">
              <div className="bg-renata-yellow rounded-full w-10 h-10 flex items-center justify-center mr-4 mt-1 flex-shrink-0">
                <MapPin className="text-renata-black h-5 w-5" />
              </div>
              <div>
                <h4 className="font-bold text-black text-lg mb-1">Dirección</h4>
                <p className="text-renata-dark-gray">Mariano Fragueiro 3746, Córdoba, Argentina</p>
              </div>
            </div>

            {/* Map placeholder */}
            <div className="mt-8 h-64 bg-renata-gray rounded-lg overflow-hidden shadow-md flex items-center justify-center">
              <div className="text-renata-dark-gray text-center p-4">
                <MapPin className="h-8 w-8 mx-auto mb-2 text-renata-yellow" />
                <p>Mapa de ubicación</p>
                <p className="text-sm mt-2"><iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3406.573847648069!2d-64.18359029999999!3d-31.370736999999995!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x94329852a13f9bc3%3A0x177df0cae3c2e82d!2sMariano%20Fragueiro%203746%2C%20X5000%20C%C3%B3rdoba!5e0!3m2!1ses!2sar!4v1746222925532!5m2!1ses!2sar" width="600" height="450" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe></p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ContactPage;
