# Distribuidora Renata - Sitio Web

Este es el sitio web oficial de Distribuidora Renata, una distribuidora de alimentos con un catálogo de productos en línea y panel de administración.

## Características

- ✨ Diseño moderno y responsive adaptado a todos los dispositivos
- 💻 Catálogo de productos organizado por categorías
- 🔐 Sistema de autenticación para administradores
- 📊 Panel de administración para gestionar productos y categorías
- 📧 Formulario de contacto funcional

## Tecnologías Utilizadas

- **Frontend**: React, TailwindCSS, React Query
- **Backend**: Node.js, Express
- **Almacenamiento**: Base de datos en memoria (puede ser actualizada a PostgreSQL)
- **Autenticación**: Passport.js con sesión local

## Comenzando

### Requisitos previos

- Node.js v20 o superior

### Instalación

1. Clona este repositorio

2. Instala las dependencias:
   ```bash
   npm install
   ```

3. Inicia el servidor de desarrollo:
   ```bash
   npm run dev
   ```

4. Abre tu navegador en [http://localhost:5000](http://localhost:5000)

## Configuración Inicial

Cuando accedes por primera vez al sitio, no hay productos ni categorías. Para configurar el sitio:

1. Crea una cuenta de usuario desde la página de acceso (`/auth`)

2. Convierte tu cuenta en administrador ejecutando:
   ```bash
   node make-admin.js TU_NOMBRE_DE_USUARIO
   ```

3. Inicia sesión con esta cuenta y accede al panel de administración en `/admin`

4. Alternativamente, puedes cargar datos de ejemplo ejecutando:
   ```bash
   node seed-data.js
   ```

## Personalización

Puedes personalizar:

- Colores: Edita el archivo `tailwind.config.ts` para cambiar los colores principales
- Contenido: Usa el panel de administración para gestionar productos y categorías
- Imágenes: Actualiza las imágenes en las secciones "Nosotros" y "Contacto"

## Administración

Consulta el archivo [GUIA-DE-ADMIN.md](./GUIA-DE-ADMIN.md) para instrucciones detalladas sobre cómo utilizar el panel de administración.

## Estructura del Proyecto

```
├── client/         # Código del frontend (React)
├── server/         # Código del backend (Express)
├── shared/         # Esquemas y tipos compartidos
└── ...             # Archivos de configuración
```

## Despliegue

Para desplegar en producción:

1. Construye el frontend:
   ```bash
   npm run build
   ```

2. Inicia el servidor de producción:
   ```bash
   npm start
   ```

## Soporte

Si encuentras problemas o tienes preguntas, contacta al desarrollador.
