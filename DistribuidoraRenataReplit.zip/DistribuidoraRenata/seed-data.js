const { storage } = require('./server/storage');

async function seedData() {
  try {
    // Seed initial data
    await storage.seedInitialData();
    console.log('✅ Initial product data has been seeded successfully!');
    console.log('You can now log in and see products and categories on the website.');
  } catch (error) {
    console.error('❌ Error:', error.message);
  }
}

seedData().then(() => process.exit(0));
