import { 
  users, 
  categories, 
  products, 
  contacts,
  type User, 
  type InsertUser, 
  type Category, 
  type InsertCategory, 
  type Product, 
  type InsertProduct, 
  type Contact,
  type InsertContact 
} from "@shared/schema";
import expressSession from "express-session";
import { db } from "./db";
import { pool } from "./db";
import { eq, desc } from "drizzle-orm";

// Connect-PG-Simple for PostgreSQL session store
// Use dynamic import for ESM compatibility
import { createRequire } from 'module';
const require = createRequire(import.meta.url);
const connectPgSimple = require('connect-pg-simple');
const PostgresSessionStore = connectPgSimple(expressSession);

// Storage interface
export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, user: Partial<User>): Promise<User | undefined>;

  // Category methods
  getAllCategories(): Promise<Category[]>;
  getCategory(id: number): Promise<Category | undefined>;
  createCategory(category: InsertCategory): Promise<Category>;
  updateCategory(id: number, category: InsertCategory): Promise<Category | undefined>;
  deleteCategory(id: number): Promise<boolean>;

  // Product methods
  getAllProducts(categoryId?: number): Promise<Product[]>;
  getProduct(id: number): Promise<Product | undefined>;
  createProduct(product: InsertProduct): Promise<Product>;
  updateProduct(id: number, product: InsertProduct): Promise<Product | undefined>;
  deleteProduct(id: number): Promise<boolean>;

  // Contact methods
  createContact(contact: InsertContact): Promise<Contact>;
  getAllContacts(): Promise<Contact[]>;

  // Demo data
  seedInitialData(): Promise<void>;

  // Session store
  sessionStore: expressSession.Store;
}

export class DatabaseStorage implements IStorage {
  sessionStore: expressSession.Store;

  constructor() {
    this.sessionStore = new PostgresSessionStore({
      pool,
      createTableIfMissing: true
    });
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(user: InsertUser): Promise<User> {
    const [newUser] = await db.insert(users).values(user).returning();
    return newUser;
  }

  async updateUser(id: number, user: Partial<User>): Promise<User | undefined> {
    const [updatedUser] = await db
      .update(users)
      .set(user)
      .where(eq(users.id, id))
      .returning();
    return updatedUser || undefined;
  }

  // Category methods
  async getAllCategories(): Promise<Category[]> {
    return await db.select().from(categories);
  }

  async getCategory(id: number): Promise<Category | undefined> {
    const [category] = await db.select().from(categories).where(eq(categories.id, id));
    return category || undefined;
  }

  async createCategory(category: InsertCategory): Promise<Category> {
    const [newCategory] = await db.insert(categories).values(category).returning();
    return newCategory;
  }

  async updateCategory(id: number, category: InsertCategory): Promise<Category | undefined> {
    const [updatedCategory] = await db
      .update(categories)
      .set(category)
      .where(eq(categories.id, id))
      .returning();
    return updatedCategory || undefined;
  }

  async deleteCategory(id: number): Promise<boolean> {
    // First update products to remove category reference
    await db
      .update(products)
      .set({ categoryId: null })
      .where(eq(products.categoryId, id));

    // Then delete the category
    const result = await db.delete(categories).where(eq(categories.id, id)).returning();
    return result.length > 0;
  }

  // Product methods
  async getAllProducts(categoryId?: number): Promise<Product[]> {
    if (categoryId) {
      return await db
        .select()
        .from(products)
        .where(eq(products.categoryId, categoryId));
    } else {
      return await db.select().from(products);
    }
  }

  async getProduct(id: number): Promise<Product | undefined> {
    const [product] = await db.select().from(products).where(eq(products.id, id));
    return product || undefined;
  }

  async createProduct(product: InsertProduct): Promise<Product> {
    const [newProduct] = await db.insert(products).values(product).returning();
    return newProduct;
  }

  async updateProduct(id: number, product: InsertProduct): Promise<Product | undefined> {
    const [updatedProduct] = await db
      .update(products)
      .set(product)
      .where(eq(products.id, id))
      .returning();
    return updatedProduct || undefined;
  }

  async deleteProduct(id: number): Promise<boolean> {
    const result = await db.delete(products).where(eq(products.id, id)).returning();
    return result.length > 0;
  }

  // Contact methods
  async createContact(contact: InsertContact): Promise<Contact> {
    const [newContact] = await db.insert(contacts).values(contact).returning();
    return newContact;
  }

  async getAllContacts(): Promise<Contact[]> {
    return await db.select().from(contacts).orderBy(desc(contacts.createdAt));
  }

  // Seed initial data
  async seedInitialData(): Promise<void> {
    // Create admin user if it doesn't exist
    const adminUser = await this.getUserByUsername("admin");
    if (!adminUser) {
      await db.insert(users).values({
        username: "admin",
        password: "c7ad44cbad762a5da0a452f9e854fdc1e0e7a52a38015f23f3eab1d80b931dd472634dfac71cd34ebc35d16ab7fb8a90c81f975113d6c7538dc69dd8de9077ec.e4b5d93730c9becd538a51d9cbdd3f3e", // admin
        isAdmin: true
      });
    }

    // Seed categories if empty
    const categoryCount = await db.select().from(categories);
    if (categoryCount.length === 0) {
      const categoryData = [
        {
          name: "Lácteos",
          description: "Quesos, leche, yogurt",
          imageUrl: "https://images.unsplash.com/photo-1590779033100-9f60a05a013d?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80"
        },
        {
          name: "Enlatados",
          description: "Conservas, salsas, legumbres",
          imageUrl: "https://images.unsplash.com/photo-1509440159596-0249088772ff?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80"
        },
        {
          name: "Aceites y Condimentos",
          description: "Aceites, especias, aderezos",
          imageUrl: "https://images.unsplash.com/photo-1625602812206-5ec545ca1231?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80"
        },
        {
          name: "Bebidas",
          description: "Jugos, refrescos, agua",
          imageUrl: "https://images.unsplash.com/photo-1621066875197-4eda31f96564?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80"
        }
      ];

      await db.insert(categories).values(categoryData);
    }

    // Get the categories
    const allCategories = await this.getAllCategories();
    const dairyCategory = allCategories.find(c => c.name === "Lácteos");
    const oilsCategory = allCategories.find(c => c.name === "Aceites y Condimentos");
    const cannedCategory = allCategories.find(c => c.name === "Enlatados");
    const beveragesCategory = allCategories.find(c => c.name === "Bebidas");

    // Seed products if empty
    const productCount = await db.select().from(products);
    if (productCount.length === 0) {
      const productData = [
        {
          name: "Leche Entera",
          description: "Leche entera de alta calidad, pasteurizada y homogeneizada. Caja de 12 litros.",
          price: 24.99,
          imageUrl: "https://images.unsplash.com/photo-1559598467-f8b76c8155d0?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80",
          categoryId: dairyCategory?.id,
          stock: 100,
          featured: true,
          tag: "POPULAR"
        },
        {
          name: "Aceite de Oliva Extra Virgen",
          description: "Aceite de oliva extra virgen prensado en frío. Caja con 6 botellas de 1 litro.",
          price: 89.50,
          imageUrl: "https://images.unsplash.com/photo-1625938144755-652e08e359b7?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80",
          categoryId: oilsCategory?.id,
          stock: 50,
          featured: false,
          tag: null
        },
        {
          name: "Atún en Agua",
          description: "Atún en agua de alta calidad. Caja con 24 latas de 170g cada una.",
          price: 68.75,
          imageUrl: "https://images.unsplash.com/photo-1534483509719-3feaee7c30da?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80",
          categoryId: cannedCategory?.id,
          stock: 75,
          featured: true,
          tag: "OFERTA"
        },
        {
          name: "Queso Gouda",
          description: "Queso Gouda en presentación de rueda completa de 4kg. Ideal para restaurantes.",
          price: 120.00,
          imageUrl: "https://images.unsplash.com/photo-1596803244018-908d27aa0bad?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80",
          categoryId: dairyCategory?.id,
          stock: 30,
          featured: false,
          tag: null
        },
        {
          name: "Jugo de Naranja Natural",
          description: "Jugo de naranja 100% natural. Caja con 12 botellas de 1 litro.",
          price: 45.25,
          imageUrl: "https://images.unsplash.com/photo-1600271886742-f049cd451bba?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80",
          categoryId: beveragesCategory?.id,
          stock: 60,
          featured: false,
          tag: null
        },
        {
          name: "Sal Marina Gourmet",
          description: "Sal marina natural. Caja con 12 paquetes de 1kg cada uno.",
          price: 35.80,
          imageUrl: "https://images.unsplash.com/photo-1615485290382-441e4d049cb5?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80",
          categoryId: oilsCategory?.id,
          stock: 45,
          featured: false,
          tag: null
        },
        {
          name: "Frijoles Refritos",
          description: "Frijoles refritos tradicionales. Caja con 24 latas de 440g cada una.",
          price: 52.40,
          imageUrl: "https://images.unsplash.com/photo-1612000529646-f424a2aa1bff?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80",
          categoryId: cannedCategory?.id,
          stock: 40,
          featured: true,
          tag: "NUEVO"
        },
        {
          name: "Agua Mineral",
          description: "Agua mineral premium. Paquete con 24 botellas de 500ml cada una.",
          price: 18.99,
          imageUrl: "https://images.unsplash.com/photo-1563729784474-d77dbb933a9e?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80",
          categoryId: beveragesCategory?.id,
          stock: 120,
          featured: false,
          tag: null
        }
      ];

      await db.insert(products).values(productData);
    }
  }
}

// Use DatabaseStorage instead of MemStorage
export const storage = new DatabaseStorage();