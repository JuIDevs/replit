
import { Pool } from '@neondatabase/serverless';
import { drizzle } from 'drizzle-orm/neon-serverless';
import { eq } from 'drizzle-orm';
import { users } from './server/schema.js';

const pool = new Pool({ connectionString: process.env.DATABASE_URL });
const db = drizzle(pool);

async function makeAdmin(username) {
  try {
    // Get the user
    const [user] = await db.select().from(users).where(eq(users.username, username));
    
    if (!user) {
      console.error(`User ${username} not found. Please create this account first.`);
      process.exit(1);
    }
    
    // Update the user to be an admin in the database
    const [updatedUser] = await db
      .update(users)
      .set({ isAdmin: true })
      .where(eq(users.id, user.id))
      .returning();
    
    console.log(`User ${username} has been made an admin.`);
  } catch (error) {
    console.error('Error:', error.message);
    process.exit(1);
  } finally {
    await pool.end();
  }
}

// Get username from command line argument
const username = process.argv[2];

if (!username) {
  console.error('Please provide a username: node make-admin.js YOUR_USERNAME');
  process.exit(1);
} else {
  makeAdmin(username);
}
