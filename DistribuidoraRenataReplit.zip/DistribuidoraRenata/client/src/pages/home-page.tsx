import React from 'react';
import Hero from '@/components/home/hero';
import Categories from '@/components/home/categories';
import ProductGrid from '@/components/products/product-grid';
import Services from '@/components/home/services';
import Testimonials from '@/components/home/testimonials';
import { useQuery } from '@tanstack/react-query';
import { Product } from '@shared/schema';
import { Loader2 } from 'lucide-react';

const HomePage = () => {
  const { data: products, isLoading } = useQuery<Product[]>({
    queryKey: ['/api/products'],
  });

  // Get featured products
  const featuredProducts = products?.filter(product => product.featured) || [];

  return (
    <div>
      <Hero />
      <Categories />
      
      {/* Featured Products Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-inter font-bold text-renata-black text-center mb-2">Productos Destacados</h2>
          <p className="text-renata-dark-gray text-center mb-12">Descubre nuestra selección especial de productos</p>
          
          {isLoading ? (
            <div className="flex justify-center py-12">
              <Loader2 className="h-8 w-8 animate-spin text-renata-yellow" />
            </div>
          ) : featuredProducts.length > 0 ? (
            <ProductGrid products={featuredProducts} />
          ) : (
            <p className="text-center py-12 text-gray-500">No hay productos destacados disponibles</p>
          )}
          
          <div className="mt-8 text-center">
            <a 
              href="/products" 
              className="inline-flex items-center justify-center px-6 py-3 border border-transparent text-base font-medium rounded-md text-white bg-renata-black hover:bg-opacity-90 transition-colors"
            >
              Ver todos los productos
            </a>
          </div>
        </div>
      </section>
      
      <Services />
      <Testimonials />
    </div>
  );
};

export default HomePage;
