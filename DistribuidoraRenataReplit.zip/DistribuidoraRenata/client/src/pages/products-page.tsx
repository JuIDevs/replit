import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Product, Category } from '@shared/schema';
import { Loader2 } from 'lucide-react';
import ProductFilters from '@/components/products/product-filters';
import ProductGrid from '@/components/products/product-grid';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Search } from 'lucide-react';

const ProductsPage = () => {
  const [selectedCategory, setSelectedCategory] = useState<number | null>(null);
  const [searchQuery, setSearchQuery] = useState('');

  const { data: categories, isLoading: categoriesLoading } = useQuery<Category[]>({
    queryKey: ['/api/categories'],
  });

  const { data: products, isLoading: productsLoading } = useQuery<Product[]>({
    queryKey: ['/api/products', selectedCategory],
    queryFn: async () => {
      const url = selectedCategory 
        ? `/api/products?categoryId=${selectedCategory}` 
        : '/api/products';
      const res = await fetch(url);
      if (!res.ok) {
        throw new Error('Failed to fetch products');
      }
      return res.json();
    },
  });

  // Filter products by search query
  const filteredProducts = products?.filter(product => 
    product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    (product.description && product.description.toLowerCase().includes(searchQuery.toLowerCase()))
  ) || [];

  const isLoading = categoriesLoading || productsLoading;

  return (
    <section id="products" className="py-16 bg-renata-gray">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-inter font-bold text-renata-black text-center mb-2">Nuestros Productos</h2>
        <p className="text-renata-dark-gray text-center mb-8">Descubre nuestra selección de productos alimenticios de alta calidad</p>

        {/* Search and Filters */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8">
          <ProductFilters 
            categories={categories || []} 
            selectedCategory={selectedCategory}
            setSelectedCategory={setSelectedCategory}
            isLoading={categoriesLoading}
          />
          
          <div className="w-full md:w-auto relative">
            <Input
              type="text"
              placeholder="Buscar productos..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10"
            />
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
          </div>
        </div>

        {/* Products Grid */}
        {isLoading ? (
          <div className="flex justify-center py-20">
            <Loader2 className="h-8 w-8 animate-spin text-renata-yellow" />
          </div>
        ) : filteredProducts.length > 0 ? (
          <ProductGrid products={filteredProducts} />
        ) : (
          <div className="text-center py-20">
            <p className="text-lg text-gray-500 mb-4">No se encontraron productos</p>
            <Button 
              variant="outline" 
              onClick={() => {
                setSelectedCategory(null);
                setSearchQuery('');
              }}
            >
              Limpiar filtros
            </Button>
          </div>
        )}
      </div>
    </section>
  );
};

export default ProductsPage;
