import React from 'react';
import { Truck, Users, Package, Clock } from 'lucide-react';

const AboutPage = () => {
  return (
    <section id="about" className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-inter font-bold text-renata-black text-center mb-6">Sobre Nosotros</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center mt-12">
          <div>
            <h3 className="text-2xl font-inter font-bold text-renata-black mb-6">Sobre Distribuidora Renata</h3>
            <div className="space-y-4">
              <p className="text-renata-dark-gray">Fundada en 2005, Distribuidora Renata se ha convertido en un referente en la distribución de productos alimenticios de alta calidad para restaurantes, hoteles, cafeterías y tiendas minoristas.</p>
              <p className="text-renata-dark-gray">Nuestra misión es proporcionar productos de la más alta calidad, cumpliendo con todas las normas sanitarias y de seguridad alimentaria, garantizando la satisfacción total de nuestros clientes.</p>
              <p className="text-renata-dark-gray">Contamos con un amplio catálogo de productos nacionales e importados, y una infraestructura logística que nos permite entregar pedidos de manera rápida y eficiente en todo el territorio nacional.</p>
            </div>
            
            <div className="mt-8 grid grid-cols-2 gap-4">
              <div className="bg-renata-gray p-4 rounded-lg">
                <div className="text-renata-yellow text-3xl font-bold mb-2">+500</div>
                <p className="text-renata-dark-gray font-medium">Clientes satisfechos</p>
              </div>
              <div className="bg-renata-gray p-4 rounded-lg">
                <div className="text-renata-yellow text-3xl font-bold mb-2">+1000</div>
                <p className="text-renata-dark-gray font-medium">Productos diferentes</p>
              </div>
              <div className="bg-renata-gray p-4 rounded-lg">
                <div className="text-renata-yellow text-3xl font-bold mb-2">32</div>
                <p className="text-renata-dark-gray font-medium">Ciudades con entrega</p>
              </div>
              <div className="bg-renata-gray p-4 rounded-lg">
                <div className="text-renata-yellow text-3xl font-bold mb-2">15+</div>
                <p className="text-renata-dark-gray font-medium">Años de experiencia</p>
              </div>
            </div>
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div className="relative h-64 rounded-lg overflow-hidden shadow-lg">
              <img src="https://lh3.googleusercontent.com/gps-cs-s/AC9h4nqDb2K2Jr8ru-ICHJ_Ru8cxLfRqB1soYeSKXsNUIQXiBUDisD19DmHd-IHpaVhoXTBJRnekK9dSjKhBfzmWp1d4fcEu1-kMke7dASM8xraNcdstxGlxdNgyQ_SqZqGqg5P5Os9KKw=s680-w680-h510-rw" alt="Warehouse food distribution" className="w-full h-full object-cover" />
            </div>
            <div className="relative h-64 rounded-lg overflow-hidden shadow-lg mt-8">
              <img src="https://lh3.googleusercontent.com/p/AF1QipPJWDYiZlTe6763Xj3rwv2Hmm4q-Zhv39udZQYa=s680-w680-h510-rw" alt="Food packaging and delivery" className="w-full h-full object-cover" />
            </div>
            <div className="relative h-64 rounded-lg overflow-hidden shadow-lg">
              <img src="https://lh3.googleusercontent.com/p/AF1QipPsMOpME_uHQpBz4ndh2TsvxJts-OEd1AoGskjQ=s680-w680-h510-rw" alt="Food distribution products" className="w-full h-full object-cover" />
            </div>
            <div className="relative h-64 rounded-lg overflow-hidden shadow-lg mt-8">
              <img src="https://lh3.googleusercontent.com/p/AF1QipNi-6AHe6Xf3AP5Df3OPrPbkEJ09XqEjXVJJADI=s680-w680-h510-rw" alt="Warehouse food stock" className="w-full h-full object-cover" />
            </div>
          </div>
        </div>
        
        {/* Values section */}
        <div className="mt-20">
          <h3 className="text-2xl font-inter font-bold text-renata-black text-center mb-12">Nuestros Valores</h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="bg-renata-gray p-6 rounded-lg text-center">
              <div className="bg-renata-yellow rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <Package className="h-8 w-8 text-renata-black" />
              </div>
              <h4 className="text-xl text-black font-bold mb-3">Calidad</h4>
              <p className="text-renata-dark-gray">Seleccionamos cuidadosamente cada producto para garantizar la más alta calidad para nuestros clientes.</p>
            </div>
            
            <div className="bg-renata-gray p-6 rounded-lg text-center">
              <div className="bg-renata-yellow rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <Clock className="h-8 w-8 text-renata-black" />
              </div>
              <h4 className="text-xl text-black font-bold mb-3">Puntualidad</h4>
              <p className="text-renata-dark-gray">Cumplimos rigurosamente con los plazos de entrega acordados con nuestros clientes.</p>
            </div>
            
            <div className="bg-renata-gray p-6 rounded-lg text-center">
              <div className="bg-renata-yellow rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <Users className="h-8 w-8 text-renata-black" />
              </div>
              <h4 className="text-xl text-black font-bold mb-3">Atención al Cliente</h4>
              <p className="text-renata-dark-gray">Brindamos un servicio personalizado y atención dedicada a cada uno de nuestros clientes.</p>
            </div>
            
            <div className="bg-renata-gray p-6 rounded-lg text-center">
              <div className="bg-renata-yellow rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <Truck className="h-8 w-8 text-renata-black" />
              </div>
              <h4 className="text-xl text-black font-bold mb-3">Logística Eficiente</h4>
              <p className="text-renata-dark-gray">Contamos con una red logística optimizada para entregar los productos en perfectas condiciones.</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutPage;
