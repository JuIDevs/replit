import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { Category } from '@shared/schema';
import { Loader2 } from 'lucide-react';
import { Link } from 'wouter';
import { cn } from '@/lib/utils';

const CategoryCard = ({ category }: { category: Category }) => {
  return (
    <div className="bg-renata-gray rounded-lg shadow-md overflow-hidden transition-transform hover:scale-105">
      <div className="h-40 overflow-hidden">
        <img 
          src={category.imageUrl || "https://via.placeholder.com/500x500?text=No+Image"} 
          alt={category.name} 
          className="w-full h-full object-cover"
        />
      </div>
      <div className="p-4 text-center">
        <h3 className="font-inter font-bold text-lg mb-1">{category.name}</h3>
        <p className="text-sm text-renata-dark-gray mb-3">{category.description}</p>
        <Link href={`/products?category=${category.id}`}>
          <a className="text-renata-black font-medium hover:text-renata-yellow transition-colors">
            Ver productos 
            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 inline-block ml-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" />
            </svg>
          </a>
        </Link>
      </div>
    </div>
  );
};

const Categories = () => {
  const { data: categories, isLoading, error } = useQuery<Category[]>({
    queryKey: ['/api/categories'],
  });

  return (
    <section className="bg-white py-12">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-inter font-bold text-renata-black text-center mb-2">Nuestras Categorías</h2>
        <p className="text-renata-dark-gray text-center mb-12">Explora nuestra amplia gama de productos alimenticios</p>
        
        {isLoading ? (
          <div className="flex justify-center py-12">
            <Loader2 className="h-8 w-8 animate-spin text-renata-yellow" />
          </div>
        ) : error ? (
          <div className="text-center py-12">
            <p className="text-red-500">Error al cargar las categorías</p>
          </div>
        ) : categories && categories.length > 0 ? (
          <div className={cn(
            "grid gap-6",
            categories.length >= 4 ? "grid-cols-2 md:grid-cols-3 lg:grid-cols-4" : 
            categories.length === 3 ? "grid-cols-2 md:grid-cols-3" : 
            categories.length === 2 ? "grid-cols-2" : "grid-cols-1"
          )}>
            {categories.map(category => (
              <CategoryCard key={category.id} category={category} />
            ))}
          </div>
        ) : (
          <div className="text-center py-12">
            <p className="text-gray-500">No hay categorías disponibles</p>
          </div>
        )}
      </div>
    </section>
  );
};

export default Categories;
