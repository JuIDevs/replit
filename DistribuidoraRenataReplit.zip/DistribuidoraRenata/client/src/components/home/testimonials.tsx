import React from "react";

interface Testimonial {
  rating: number;
  text: string;
  name: string;
  company: string;
  imageUrl: string;
}

const testimonials: Testimonial[] = [
  {
    rating: 5,
    text: "Quiero felicitar a Renata por la atención de su equipo de trabajo, ¡es excepcional! Es algo que me sorprendió gratamente desde que descubri esta distribuidora. Muy recomendable.",
    name: "Norma Alicia Hernández",
    company: "",
    imageUrl:
      "https://lh3.googleusercontent.com/a/ACg8ocKRbSo94BVa6t8N5HTVg__m-XcDl1jiCQtbrYzgYlG0hBRnQw=w72-h72-p-rp-mo-br100",
  },
  {
    rating: 5,
    text: "Excelente distribuidora. Muy buenos precios y variedad de productos. Excelente atención.",
    name: "Marcos Gustavo Charaf",
    company: "Guía Local Nivel 8",
    imageUrl:
      "https://lh3.googleusercontent.com/a-/ALV-UjWyAI-Z7784GrUIiG6Cue_i548FXpX4xJLWHwPPtRkYrN2EmiSI=w72-h72-p-rp-mo-ba6-br100",
  },
  {
    rating: 5,
    text: "Gran variedad de productos y marcas. A destacar la atención del personal, ¡siempre excelente!",
    name: "Julieta Rojas",
    company: "",
    imageUrl:
      "https://lh3.googleusercontent.com/a/ACg8ocKYODtnqr65F3NlKN7QnokBjEz2IKb8ulYPZxEkw4VccLcasg=w72-h72-p-rp-mo-ba1-br100",
  },
];

const TestimonialCard = ({ testimonial }: { testimonial: Testimonial }) => {
  // Create the star rating display
  const renderStars = (rating: number) => {
    const stars = [];
    const fullStars = Math.floor(rating);
    const halfStar = rating % 1 !== 0;

    // Add full stars
    for (let i = 0; i < fullStars; i++) {
      stars.push(
        <svg
          key={`star-${i}`}
          xmlns="http://www.w3.org/2000/svg"
          className="h-5 w-5"
          viewBox="0 0 20 20"
          fill="currentColor"
        >
          <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
        </svg>,
      );
    }

    // Add half star if needed
    if (halfStar) {
      stars.push(
        <svg
          key="half-star"
          xmlns="http://www.w3.org/2000/svg"
          className="h-5 w-5"
          viewBox="0 0 20 20"
          fill="currentColor"
        >
          <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
        </svg>,
      );
    }

    return stars;
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-md">
      <div className="flex items-center mb-4">
        <div className="text-renata-yellow flex">
          {renderStars(testimonial.rating)}
        </div>
        <span className="ml-2 text-sm font-medium">
          {testimonial.rating.toFixed(1)}
        </span>
      </div>
      <p className="text-renata-dark-gray mb-6">{testimonial.text}</p>
      <div className="flex items-center">
        <div className="w-12 h-12 bg-renata-gray rounded-full overflow-hidden mr-4">
          <img
            src={testimonial.imageUrl}
            alt={testimonial.name}
            className="w-full h-full object-cover"
          />
        </div>
        <div>
          <h4 className="font-medium">{testimonial.name}</h4>
          <p className="text-sm text-gray-500">{testimonial.company}</p>
        </div>
      </div>
    </div>
  );
};

const Testimonials = () => {
  return (
    <section className="py-16 bg-renata-gray">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-inter font-bold text-renata-black text-center mb-2">
          Lo Que Dicen Nuestros Clientes
        </h2>
        <p className="text-renata-dark-gray text-center mb-12">
          Testimonios de quienes confían en nosotros
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <TestimonialCard key={index} testimonial={testimonial} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default Testimonials;
