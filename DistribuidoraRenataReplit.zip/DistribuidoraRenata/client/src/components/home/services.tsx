import React from 'react';
import { Truck, Warehouse, Forklift } from 'lucide-react';
import { Link } from 'wouter';

const Services = () => {
  return (
    <section className="py-16 bg-renata-black">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-inter font-bold text-white text-center mb-2">Nuestros Servicios</h2>
        <p className="text-gray-300 text-center mb-12">Soluciones completas para tu negocio</p>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="bg-white/5 backdrop-blur-sm p-6 rounded-lg hover:bg-white/10 transition-colors">
            <div className="bg-renata-yellow rounded-full w-16 h-16 flex items-center justify-center mb-6">
              <Forklift className="text-renata-black text-2xl" />
            </div>
            <h3 className="text-xl font-inter font-bold text-white mb-4">Distribución Mayorista</h3>
            <p className="text-gray-300 mb-4">
              Ofrecemos productos alimenticios en grandes cantidades para negocios, con precios competitivos y entregas puntuales.
            </p>
            <Link href="/contact">
              <a className="text-renata-yellow hover:text-white transition-colors font-medium">
                Más información 
                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 inline-block ml-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" />
                </svg>
              </a>
            </Link>
          </div>
          
          <div className="bg-white/5 backdrop-blur-sm p-6 rounded-lg hover:bg-white/10 transition-colors">
            <div className="bg-renata-yellow rounded-full w-16 h-16 flex items-center justify-center mb-6">
              <Warehouse className="text-renata-black text-2xl" />
            </div>
            <h3 className="text-xl font-inter font-bold text-white mb-4">Almacenamiento</h3>
            <p className="text-gray-300 mb-4">
              Contamos con instalaciones especializadas para el correcto almacenamiento de productos alimenticios, garantizando su frescura y calidad.
            </p>
            <Link href="/contact">
              <a className="text-renata-yellow hover:text-white transition-colors font-medium">
                Más información 
                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 inline-block ml-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" />
                </svg>
              </a>
            </Link>
          </div>
          
          <div className="bg-white/5 backdrop-blur-sm p-6 rounded-lg hover:bg-white/10 transition-colors">
            <div className="bg-renata-yellow rounded-full w-16 h-16 flex items-center justify-center mb-6">
              <Truck className="text-renata-black text-2xl" />
            </div>
            <h3 className="text-xl font-inter font-bold text-white mb-4">Logística y Transporte</h3>
            <p className="text-gray-300 mb-4">
              Servicio de entrega eficiente y puntual con vehículos especializados para el transporte seguro de alimentos.
            </p>
            <Link href="/contact">
              <a className="text-renata-yellow hover:text-white transition-colors font-medium">
                Más información 
                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 inline-block ml-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" />
                </svg>
              </a>
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Services;
