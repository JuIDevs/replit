import React from 'react';
import { Product, Category } from '@shared/schema';
import ProductCard from './product-card';
import { useQuery } from '@tanstack/react-query';

interface ProductGridProps {
  products: Product[];
  limit?: number;
}

const ProductGrid = ({ products, limit }: ProductGridProps) => {
  const { data: categories } = useQuery<Category[]>({
    queryKey: ['/api/categories'],
  });

  // Apply limit if specified
  const displayProducts = limit ? products.slice(0, limit) : products;

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
      {displayProducts.map(product => (
        <ProductCard 
          key={product.id} 
          product={product} 
          categories={categories || []} 
        />
      ))}
    </div>
  );
};

export default ProductGrid;
