import React from 'react';
import { Category } from '@shared/schema';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';

interface ProductFiltersProps {
  categories: Category[];
  selectedCategory: number | null;
  setSelectedCategory: (categoryId: number | null) => void;
  isLoading?: boolean;
}

const ProductFilters = ({
  categories,
  selectedCategory,
  setSelectedCategory,
  isLoading = false
}: ProductFiltersProps) => {
  
  if (isLoading) {
    return (
      <div className="flex flex-wrap gap-2 mb-4">
        <Skeleton className="h-10 w-20" />
        <Skeleton className="h-10 w-24" />
        <Skeleton className="h-10 w-28" />
        <Skeleton className="h-10 w-24" />
      </div>
    );
  }

  return (
    <div className="flex flex-wrap gap-2 mb-4">
      <Button
        variant={selectedCategory === null ? "default" : "outline"}
        className={selectedCategory === null ? "bg-renata-black text-white" : ""}
        onClick={() => setSelectedCategory(null)}
      >
        Todos
      </Button>
      
      {categories.map((category) => (
        <Button
          key={category.id}
          variant={selectedCategory === category.id ? "default" : "outline"}
          className={
            selectedCategory === category.id 
              ? "bg-renata-yellow text-renata-black hover:bg-[#ddb012]" 
              : "hover:bg-renata-yellow hover:text-renata-black"
          }
          onClick={() => setSelectedCategory(category.id)}
        >
          {category.name}
        </Button>
      ))}
    </div>
  );
};

export default ProductFilters;
