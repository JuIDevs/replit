import React from 'react';
import { Product, Category } from '@shared/schema';
import { Link } from 'wouter';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

interface ProductCardProps {
  product: Product;
  categories?: Category[];
}

const ProductCard = ({ product, categories = [] }: ProductCardProps) => {
  // Find the category name for this product
  const category = categories.find(c => c.id === product.categoryId);
  const categoryName = category ? category.name : 'Sin categoría';

  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden transition-transform hover:scale-105">
      <div className="h-56 overflow-hidden relative">
        <img 
          src={product.imageUrl || "https://via.placeholder.com/500x500?text=No+Image"} 
          alt={product.name} 
          className="w-full h-full object-cover"
        />
        {product.tag && (
          <div className={cn(
            "absolute top-0 left-0 text-xs font-bold px-2 py-1 m-2 rounded",
            product.tag === "POPULAR" ? "bg-renata-yellow text-renata-black" :
            product.tag === "NUEVO" || product.tag === "NEW" ? "bg-green-500 text-white" :
            product.tag === "OFERTA" || product.tag === "OFFER" ? "bg-red-500 text-white" :
            "bg-renata-yellow text-renata-black"
          )}>
            {product.tag}
          </div>
        )}
      </div>
      <div className="p-4">
        <div className="flex justify-between items-start">
          <div>
            <span className="text-xs text-gray-500">{categoryName}</span>
            <h3 className="font-inter text-black font-bold text-lg">{product.name}</h3>
          </div>
          <span className="font-bold text-lg">${product.price.toFixed(2)}</span>
        </div>
        <p className="text-sm text-renata-dark-gray mt-2 mb-4">
          {product.description || "Sin descripción disponible."}
        </p>
        <Link href="/contact">
          <Button className="w-full bg-renata-black hover:bg-opacity-80 text-white font-bold">
            Solicitar información
          </Button>
        </Link>
      </div>
    </div>
  );
};

export default ProductCard;
