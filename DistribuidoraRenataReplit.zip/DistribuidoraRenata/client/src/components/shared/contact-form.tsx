import React from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { insertContactSchema } from '@shared/schema';
import { useMutation } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { Loader2 } from 'lucide-react';

// Create a schema for the contact form
const contactFormSchema = insertContactSchema.extend({
    // Add additional validation rules
    name: z.string().min(3, 'El nombre debe tener al menos 3 caracteres'),
    company: z.string().optional(),
    email: z.string().email('Email inválido'),
    phone: z.string().min(7, 'Teléfono inválido'),
    subject: z.string().min(3, 'El asunto debe tener al menos 3 caracteres'),
    message: z.string().min(10, 'El mensaje debe tener al menos 10 caracteres'),
  });

type ContactFormValues = z.infer<typeof contactFormSchema>;

const ContactForm = () => {
  const { toast } = useToast();

  // Initialize the form
  const form = useForm<ContactFormValues>({
    resolver: zodResolver(contactFormSchema),
    defaultValues: {
      name: '',
      company: '',
      email: '',
      phone: '',
      subject: '',
      message: '',
      createdAt: '', // This will be set on submission
    },
  });

  // Contact form submission mutation
  const contactMutation = useMutation({
    mutationFn: async (data: ContactFormValues) => {
      const currentDate = new Date().toISOString();
      const formData = { ...data, createdAt: currentDate };
      const res = await apiRequest('POST', '/api/contact', formData);
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: 'Mensaje enviado',
        description: 'Hemos recibido tu mensaje. Nos pondremos en contacto contigo pronto.',
      });
      form.reset();
    },
    onError: (error: Error) => {
      toast({
        title: 'Error al enviar el mensaje',
        description: error.message || 'Ha ocurrido un error. Por favor intenta nuevamente.',
        variant: 'destructive',
      });
    },
  });

  // Handle form submission
  const onSubmit = (values: ContactFormValues) => {
    // Create WhatsApp message with form data
    const message = `Hola, soy ${values.name}${values.company ? ` de ${values.company}` : ''}. Me comunico por ${values.subject}. ${values.message}\n\nPara contactarme:\nEmail: ${values.email}\nTeléfono: ${values.phone}\n\n¡Gracias!`;

    // Format the phone number and message for WhatsApp
    const whatsappNumber = "5493512742582";
    const encodedMessage = encodeURIComponent(message);
    const whatsappUrl = `https://wa.me/${whatsappNumber}?text=${encodedMessage}`;

    // Open WhatsApp in a new tab
    window.open(whatsappUrl, '_blank');

    // Still submit to the API
    contactMutation.mutate(values);
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="name"
            render={({ field }) => (
              <FormItem>
                <FormLabel className="text-black text-lg font-bold-400">Nombre completo</FormLabel>
                <FormControl>
                  <Input placeholder="Tu nombre" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="company"
            render={({ field }) => (
              <FormItem>
                <FormLabel className="text-black text-lg font-bold-400">Empresa (Si aplica)</FormLabel>
                <FormControl>
                  <Input placeholder="Nombre de tu empresa" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="email"
            render={({ field }) => (
              <FormItem>
                <FormLabel className="text-black text-lg font-bold-400">Correo electrónico</FormLabel>
                <FormControl>
                  <Input 
                    type="email" 
                    placeholder="tu@email.com" 
                    {...field}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="phone"
            render={({ field }) => (
              <FormItem>
                <FormLabel className="text-black text-lg font-bold-400">Teléfono</FormLabel>
                <FormControl>
                  <Input 
                    type="tel" 
                    placeholder="+54 9 351 123 4567" 
                    {...field}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <FormField
          control={form.control}
          name="subject"
          render={({ field }) => (
            <FormItem>
              <FormLabel className="text-black text-lg font-bold-400">Asunto</FormLabel>
              <FormControl>
                <Input placeholder="¿Sobre qué quieres contactarnos?" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="message"
          render={({ field }) => (
            <FormItem>
              <FormLabel className="text-black text-lg font-bold-400">Mensaje</FormLabel>
              <FormControl>
                <Textarea 
                  placeholder="Escribe tu mensaje aquí..." 
                  rows={4} 
                  {...field} 
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <Button 
          type="submit"
          className="w-full bg-renata-black hover:bg-opacity-80 text-white font-bold py-3"
          disabled={contactMutation.isPending}
        >
          {contactMutation.isPending ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Enviando...
            </>
          ) : (
            'Enviar mensaje'
          )}
        </Button>
      </form>
    </Form>
  );
};

export default ContactForm;