import React, { useState } from 'react';
import { Link, useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import useMobile from '@/hooks/use-mobile';
import { useAuth } from '@/hooks/use-auth';
import { Menu, X, LogOut, User } from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

const Header = () => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const isMobile = useMobile();
  const [location] = useLocation();
  const { user, logoutMutation } = useAuth();

  const toggleMobileMenu = () => {
    setMobileMenuOpen(!mobileMenuOpen);
  };

  const closeMobileMenu = () => {
    setMobileMenuOpen(false);
  };

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  return (
    <header className="sticky top-0 z-50 bg-renata-black shadow-md">
      <nav className="container mx-auto px-4 py-3 flex items-center justify-between">
        {/* Logo */}
        <div className="flex items-center space-x-2">
          <Link href="/" className="flex items-center">
            <span className="text-renata-yellow font-inter font-bold text-2xl md:text-3xl">
              Distribuidora<span className="text-white">Renata</span>
            </span>
          </Link>
        </div>

        {/* Desktop Navigation */}
        <div className="hidden md:flex items-center space-x-6">
          <Link href="/">
            <a className={`text-white hover:text-renata-yellow font-medium transition-colors ${location === '/' ? 'text-renata-yellow' : ''}`}>
              Inicio
            </a>
          </Link>
          <Link href="/products">
            <a className={`text-white hover:text-renata-yellow font-medium transition-colors ${location === '/products' ? 'text-renata-yellow' : ''}`}>
              Productos
            </a>
          </Link>
          <Link href="/about">
            <a className={`text-white hover:text-renata-yellow font-medium transition-colors ${location === '/about' ? 'text-renata-yellow' : ''}`}>
              Nosotros
            </a>
          </Link>
          <Link href="/contact">
            <a className={`text-white hover:text-renata-yellow font-medium transition-colors ${location === '/contact' ? 'text-renata-yellow' : ''}`}>
              Contacto
            </a>
          </Link>
          
          {user ? (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="text-white hover:text-black">
                  <User className="h-4 w-4 mr-2" />
                  {user.username}
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuLabel>Mi Cuenta</DropdownMenuLabel>
                <DropdownMenuSeparator />
                {user.isAdmin && (
                  <Link href="/admin">
                    <DropdownMenuItem className="cursor-pointer">
                      Panel de Administración
                    </DropdownMenuItem>
                  </Link>
                )}
                <DropdownMenuItem className="cursor-pointer text-red-500" onClick={handleLogout}>
                  <LogOut className="h-4 w-4 mr-2" />
                  Cerrar Sesión
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          ) : (
            <Link href="/auth">
              <Button className="bg-renata-yellow hover:bg-yellow-500 text-renata-black font-bold transition-colors">
                Acceso
              </Button>
            </Link>
          )}
        </div>

        {/* Mobile Menu Button */}
        <Button 
          variant="ghost" 
          size="icon" 
          className="md:hidden text-white" 
          onClick={toggleMobileMenu}
        >
          {mobileMenuOpen ? (
            <X className="h-6 w-6" />
          ) : (
            <Menu className="h-6 w-6" />
          )}
        </Button>
      </nav>

      {/* Mobile Navigation Menu */}
      {isMobile && (
        <div className={`md:hidden bg-renata-black transition-all duration-300 ease-in-out overflow-hidden ${mobileMenuOpen ? 'max-h-screen py-3' : 'max-h-0'}`}>
          <div className="container mx-auto px-4 flex flex-col space-y-3">
            <Link href="/" onClick={closeMobileMenu}>
              <a className={`text-white hover:text-renata-yellow font-medium py-2 transition-colors ${location === '/' ? 'text-renata-yellow' : ''}`}>
                Inicio
              </a>
            </Link>
            <Link href="/products" onClick={closeMobileMenu}>
              <a className={`text-white hover:text-renata-yellow font-medium py-2 transition-colors ${location === '/products' ? 'text-renata-yellow' : ''}`}>
                Productos
              </a>
            </Link>
            <Link href="/about" onClick={closeMobileMenu}>
              <a className={`text-white hover:text-renata-yellow font-medium py-2 transition-colors ${location === '/about' ? 'text-renata-yellow' : ''}`}>
                Nosotros
              </a>
            </Link>
            <Link href="/contact" onClick={closeMobileMenu}>
              <a className={`text-white hover:text-renata-yellow font-medium py-2 transition-colors ${location === '/contact' ? 'text-renata-yellow' : ''}`}>
                Contacto
              </a>
            </Link>
            
            {user ? (
              <>
                {user.isAdmin && (
                  <Link href="/admin" onClick={closeMobileMenu}>
                    <a className="text-white hover:text-renata-yellow font-medium py-2 transition-colors">
                      Panel de Administración
                    </a>
                  </Link>
                )}
                <Button 
                  variant="ghost" 
                  className="justify-start text-red-400 hover:bg-white pl-4"
                  onClick={() => {
                    handleLogout();
                    closeMobileMenu();
                  }}
                >
                  <LogOut className="h-4 w-4 mr-2" />
                  Cerrar Sesión
                </Button>
              </>
            ) : (
              <Link href="/auth" onClick={closeMobileMenu}>
                <Button className="w-full bg-renata-yellow hover:bg-yellow-500 text-renata-black font-bold transition-colors">
                  Acceso
                </Button>
              </Link>
            )}
          </div>
        </div>
      )}
    </header>
  );
};

export default Header;
