import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { insertCategorySchema, Category } from '@shared/schema';
import { useMutation } from '@tanstack/react-query';
import { queryClient, apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Loader2 } from 'lucide-react';

interface CategoryFormProps {
  category?: Category;
  onCancel: () => void;
}

// Extend the category schema for the form validation
const categoryFormSchema = insertCategorySchema.extend({});

// Extract the type from our zod schema
type CategoryFormValues = z.infer<typeof categoryFormSchema>;

const CategoryForm = ({ category, onCancel }: CategoryFormProps) => {
  const { toast } = useToast();
  const [imagePreview, setImagePreview] = useState<string | null>(category?.imageUrl || null);

  // Creating the form with react-hook-form
  const form = useForm<CategoryFormValues>({
    resolver: zodResolver(categoryFormSchema),
    defaultValues: {
      name: category?.name || '',
      description: category?.description || '',
      imageUrl: category?.imageUrl || '',
    }
  });

  // Create or update category mutation
  const categoryMutation = useMutation({
    mutationFn: async (data: CategoryFormValues) => {
      if (category) {
        // Update existing category
        const res = await apiRequest('PUT', `/api/categories/${category.id}`, data);
        return await res.json();
      } else {
        // Create new category
        const res = await apiRequest('POST', '/api/categories', data);
        return await res.json();
      }
    },
    onSuccess: () => {
      toast({
        title: category ? 'Categoría actualizada' : 'Categoría creada',
        description: category 
          ? `La categoría ${form.getValues('name')} ha sido actualizada correctamente` 
          : `La categoría ${form.getValues('name')} ha sido creada correctamente`,
      });
      // Invalidate categories query to refresh the data
      queryClient.invalidateQueries({ queryKey: ['/api/categories'] });
      onCancel();
    },
    onError: (error: Error) => {
      toast({
        title: 'Error',
        description: `No se pudo ${category ? 'actualizar' : 'crear'} la categoría: ${error.message}`,
        variant: 'destructive',
      });
    },
  });

  // Handle image preview
  const handleImageUrlChange = (url: string) => {
    setImagePreview(url);
  };

  // Handle form submission
  const onSubmit = (values: CategoryFormValues) => {
    categoryMutation.mutate(values);
  };

  return (
    <Card className="w-full max-w-3xl mx-auto">
      <CardHeader>
        <CardTitle>{category ? 'Editar Categoría' : 'Nueva Categoría'}</CardTitle>
        <CardDescription>
          {category 
            ? 'Modifica los detalles de la categoría existente' 
            : 'Añade una nueva categoría al catálogo'}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-6">
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Nombre de la Categoría</FormLabel>
                      <FormControl>
                        <Input placeholder="Ej. Lácteos" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Descripción</FormLabel>
                      <FormControl>
                        <Textarea 
                          placeholder="Describe la categoría..." 
                          className="resize-none h-32" 
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div className="space-y-6">
                <FormField
                  control={form.control}
                  name="imageUrl"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>URL de la Imagen</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="https://ejemplo.com/imagen.jpg" 
                          {...field} 
                          onChange={(e) => {
                            field.onChange(e);
                            handleImageUrlChange(e.target.value);
                          }}
                        />
                      </FormControl>
                      <FormDescription>
                        Introduce la URL de la imagen de la categoría
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                {/* Image Preview */}
                <div className="mt-4">
                  <p className="text-sm font-medium mb-2">Vista previa:</p>
                  <div className="border rounded-md overflow-hidden h-48 bg-gray-50 flex justify-center items-center">
                    {imagePreview ? (
                      <img 
                        src={imagePreview} 
                        alt="Vista previa" 
                        className="max-w-full max-h-full object-contain" 
                        onError={() => setImagePreview(null)}
                      />
                    ) : (
                      <p className="text-gray-400 text-sm">Sin imagen</p>
                    )}
                  </div>
                </div>
              </div>
            </div>

            <div className="flex justify-end space-x-4">
              <Button 
                type="button" 
                variant="outline" 
                onClick={onCancel}
              >
                Cancelar
              </Button>
              <Button 
                type="submit"
                className="bg-renata-yellow text-renata-black hover:bg-[#ddb012]"
                disabled={categoryMutation.isPending}
              >
                {categoryMutation.isPending ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    {category ? 'Actualizando...' : 'Creando...'}
                  </>
                ) : (
                  <>{category ? 'Actualizar' : 'Crear'} Categoría</>
                )}
              </Button>
            </div>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
};

export default CategoryForm;
