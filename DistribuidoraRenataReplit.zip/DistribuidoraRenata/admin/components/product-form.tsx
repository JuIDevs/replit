import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { insertProductSchema, Product, Category } from '@shared/schema';
import { useMutation } from '@tanstack/react-query';
import { queryClient, apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';
import { Loader2 } from 'lucide-react';
import { Switch } from '@/components/ui/switch';

interface ProductFormProps {
  product?: Product;
  categories: Category[];
  onCancel: () => void;
}

// Extend the product schema for the form validation
const productFormSchema = insertProductSchema.extend({
  price: z.string().min(1, 'El precio es requerido').transform((val) => parseFloat(val)),
  stock: z.string().transform((val) => parseInt(val || '0')),
  categoryId: z.string().nullable().transform((val) => val ? parseInt(val) : null),
});

// Extract the type from our zod schema
type ProductFormValues = z.infer<typeof productFormSchema>;

const ProductForm = ({ product, categories, onCancel }: ProductFormProps) => {
  const { toast } = useToast();
  const [imagePreview, setImagePreview] = useState<string | null>(product?.imageUrl || null);

  // Creating the form with react-hook-form
  const form = useForm<ProductFormValues>({
    resolver: zodResolver(productFormSchema),
    defaultValues: {
      name: product?.name || '',
      description: product?.description || '',
      price: product?.price ? product.price.toString() : '',
      imageUrl: product?.imageUrl || '',
      categoryId: product?.categoryId ? product.categoryId.toString() : null,
      stock: product?.stock ? product.stock.toString() : '0',
      featured: product?.featured || false,
      tag: product?.tag || '',
    }
  });

  // Create or update product mutation
  const productMutation = useMutation({
    mutationFn: async (data: ProductFormValues) => {
      // Convert form values to proper types as expected by the API
      const productData = {
        ...data,
        price: parseFloat(data.price.toString()),
        stock: parseInt(data.stock.toString()),
        categoryId: data.categoryId && data.categoryId !== 'none' ? parseInt(data.categoryId.toString()) : null,
        tag: data.tag && data.tag !== 'none' ? data.tag : null,
      };

      if (product) {
        // Update existing product
        const res = await apiRequest('PUT', `/api/products/${product.id}`, productData);
        return await res.json();
      } else {
        // Create new product
        const res = await apiRequest('POST', '/api/products', productData);
        return await res.json();
      }
    },
    onSuccess: () => {
      toast({
        title: product ? 'Producto actualizado' : 'Producto creado',
        description: product 
          ? `El producto ${form.getValues('name')} ha sido actualizado correctamente` 
          : `El producto ${form.getValues('name')} ha sido creado correctamente`,
      });
      // Invalidate products query to refresh the data
      queryClient.invalidateQueries({ queryKey: ['/api/products'] });
      onCancel();
    },
    onError: (error: Error) => {
      toast({
        title: 'Error',
        description: `No se pudo ${product ? 'actualizar' : 'crear'} el producto: ${error.message}`,
        variant: 'destructive',
      });
    },
  });

  // Handle image preview
  const handleImageUrlChange = (url: string) => {
    setImagePreview(url);
  };

  // Handle form submission
  const onSubmit = (values: ProductFormValues) => {
    productMutation.mutate(values);
  };

  return (
    <Card className="w-full max-w-4xl mx-auto">
      <CardHeader>
        <CardTitle>{product ? 'Editar Producto' : 'Nuevo Producto'}</CardTitle>
        <CardDescription>
          {product 
            ? 'Modifica los detalles del producto existente' 
            : 'Añade un nuevo producto al catálogo'}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-6">
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Nombre del Producto</FormLabel>
                      <FormControl>
                        <Input placeholder="Ej. Leche Entera" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="price"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Precio ($)</FormLabel>
                      <FormControl>
                        <Input 
                          type="number" 
                          step="0.01" 
                          min="0" 
                          placeholder="Ej. 24.99" 
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="stock"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Stock</FormLabel>
                      <FormControl>
                        <Input 
                          type="number" 
                          step="1" 
                          min="0" 
                          placeholder="Ej. 100" 
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="categoryId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Categoría</FormLabel>
                      <Select 
                        onValueChange={field.onChange} 
                        defaultValue={field.value?.toString() || ''}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Selecciona una categoría" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="none">Sin categoría</SelectItem>
                          {categories.map((category) => (
                            <SelectItem key={category.id} value={category.id.toString()}>
                              {category.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="tag"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Etiqueta (Opcional)</FormLabel>
                      <Select 
                        onValueChange={field.onChange} 
                        defaultValue={field.value || 'none'}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Selecciona una etiqueta" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="none">Sin etiqueta</SelectItem>
                          <SelectItem value="POPULAR">POPULAR</SelectItem>
                          <SelectItem value="NUEVO">NUEVO</SelectItem>
                          <SelectItem value="OFERTA">OFERTA</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormDescription>
                        La etiqueta se mostrará como un distintivo en el producto
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="featured"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                      <div className="space-y-0.5">
                        <FormLabel className="text-base">Destacado</FormLabel>
                        <FormDescription>
                          Mostrar este producto en la sección de destacados
                        </FormDescription>
                      </div>
                      <FormControl>
                        <Switch
                          checked={field.value}
                          onCheckedChange={field.onChange}
                        />
                      </FormControl>
                    </FormItem>
                  )}
                />
              </div>

              <div className="space-y-6">
                <FormField
                  control={form.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Descripción</FormLabel>
                      <FormControl>
                        <Textarea 
                          placeholder="Describe el producto..." 
                          className="resize-none h-32" 
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="imageUrl"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>URL de la Imagen</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="https://ejemplo.com/imagen.jpg" 
                          {...field} 
                          onChange={(e) => {
                            field.onChange(e);
                            handleImageUrlChange(e.target.value);
                          }}
                        />
                      </FormControl>
                      <FormDescription>
                        Introduce la URL de la imagen del producto
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                {/* Image Preview */}
                <div className="mt-4">
                  <p className="text-sm font-medium mb-2">Vista previa:</p>
                  <div className="border rounded-md overflow-hidden h-48 bg-gray-50 flex justify-center items-center">
                    {imagePreview ? (
                      <img 
                        src={imagePreview} 
                        alt="Vista previa" 
                        className="max-w-full max-h-full object-contain" 
                        onError={() => setImagePreview(null)}
                      />
                    ) : (
                      <p className="text-gray-400 text-sm">Sin imagen</p>
                    )}
                  </div>
                </div>
              </div>
            </div>

            <div className="flex justify-end space-x-4">
              <Button 
                type="button" 
                variant="outline" 
                onClick={onCancel}
              >
                Cancelar
              </Button>
              <Button 
                type="submit"
                className="bg-renata-yellow text-renata-black hover:bg-[#ddb012]"
                disabled={productMutation.isPending}
              >
                {productMutation.isPending ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    {product ? 'Actualizando...' : 'Creando...'}
                  </>
                ) : (
                  <>{product ? 'Actualizar' : 'Crear'} Producto</>
                )}
              </Button>
            </div>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
};

export default ProductForm;
