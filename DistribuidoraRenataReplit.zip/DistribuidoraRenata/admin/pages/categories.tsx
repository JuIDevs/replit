import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Category } from '@shared/schema';
import { Loader2, ArrowLeft, Plus } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Link } from 'wouter';
import CategoryTable from '@/components/admin/category-table';
import CategoryForm from '@/components/admin/category-form';

const AdminCategories = () => {
  const [isCreating, setIsCreating] = useState(false);
  const [editingCategoryId, setEditingCategoryId] = useState<number | null>(null);

  const { data: categories, isLoading } = useQuery<Category[]>({
    queryKey: ['/api/categories'],
  });

  const editingCategory = editingCategoryId 
    ? categories?.find(c => c.id === editingCategoryId) 
    : null;

  return (
    <div className="py-10 bg-renata-gray min-h-screen">
      <div className="container mx-auto px-4">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-8">
          <div className="flex items-center gap-3">
            <Link href="/admin">
              <Button variant="ghost" size="icon">
                <ArrowLeft className="h-5 w-5" />
              </Button>
            </Link>
            <div>
              <h1 className="text-3xl font-bold text-renata-black">Gestión de Categorías</h1>
              <p className="text-renata-dark-gray">Administra las categorías de productos</p>
            </div>
          </div>
          {!isCreating && !editingCategory && (
            <Button 
              className="mt-4 sm:mt-0 bg-renata-yellow text-renata-black hover:bg-[#ddb012]"
              onClick={() => setIsCreating(true)}
            >
              <Plus className="h-4 w-4 mr-2" />
              Nueva Categoría
            </Button>
          )}
        </div>

        {isCreating ? (
          <CategoryForm 
            onCancel={() => setIsCreating(false)} 
          />
        ) : editingCategory ? (
          <CategoryForm 
            category={editingCategory} 
            onCancel={() => setEditingCategoryId(null)} 
          />
        ) : (
          <>
            {isLoading ? (
              <div className="flex justify-center py-20">
                <Loader2 className="h-8 w-8 animate-spin text-renata-yellow" />
              </div>
            ) : (
              <CategoryTable 
                categories={categories || []} 
                onEdit={(id) => setEditingCategoryId(id)}
              />
            )}
          </>
        )}
      </div>
    </div>
  );
};

export default AdminCategories;
