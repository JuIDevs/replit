import React, { useEffect } from 'react';
import { useAuth } from '@/hooks/use-auth';
import { Link } from 'wouter';
import { useQuery, useMutation } from '@tanstack/react-query';
import { queryClient, apiRequest } from '@/lib/queryClient';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Loader2, Package, ShoppingCart, Users, DollarSign } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

const AdminDashboard = () => {
  const { user } = useAuth();
  const { toast } = useToast();

  const { 
    data: products, 
    isLoading: productsLoading 
  } = useQuery({
    queryKey: ['/api/products'],
  });

  const { 
    data: categories, 
    isLoading: categoriesLoading 
  } = useQuery({
    queryKey: ['/api/categories'],
  });

  // Seed data mutation
  const seedMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest('POST', '/api/seed');
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: 'Datos iniciales cargados',
        description: 'Se han cargado correctamente los datos de ejemplo',
      });
      // Invalidate queries to refresh data
      queryClient.invalidateQueries({ queryKey: ['/api/products'] });
      queryClient.invalidateQueries({ queryKey: ['/api/categories'] });
    },
    onError: (error: Error) => {
      toast({
        title: 'Error al cargar datos',
        description: error.message,
        variant: 'destructive',
      });
    },
  });

  // Stats calculations
  const totalProducts = products?.length || 0;
  const totalCategories = categories?.length || 0;
  const averagePrice = products?.reduce((sum, product) => sum + product.price, 0) / totalProducts || 0;
  const totalInventoryValue = products?.reduce((sum, product) => sum + (product.price * product.stock), 0) || 0;

  const isLoading = productsLoading || categoriesLoading;

  return (
    <div className="py-10 bg-renata-gray min-h-screen">
      <div className="container mx-auto px-4">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-renata-black">Panel de Administración</h1>
            <p className="text-renata-dark-gray">Bienvenido, {user?.username}</p>
          </div>
          <div className="mt-4 sm:mt-0 flex gap-3">
            <Button 
              onClick={() => seedMutation.mutate()}
              variant="outline"
              disabled={seedMutation.isPending}
            >
              {seedMutation.isPending ? (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              ) : null}
              Cargar datos de ejemplo
            </Button>
            <div className="flex gap-2">
              <Link href="/admin/products">
                <Button className="bg-renata-yellow text-renata-black hover:bg-[#ddb012]">
                  Gestionar Productos
                </Button>
              </Link>
              <Link href="/admin/categories">
                <Button variant="outline">
                  Gestionar Categorías
                </Button>
              </Link>
            </div>
          </div>
        </div>

        {isLoading ? (
          <div className="flex justify-center py-20">
            <Loader2 className="h-8 w-8 animate-spin text-renata-yellow" />
          </div>
        ) : (
          <>
            {/* Stats Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-10">
              <Card>
                <CardHeader className="pb-2">
                  <CardDescription>Total de Productos</CardDescription>
                  <CardTitle className="text-3xl">
                    {totalProducts}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-renata-yellow">
                    <Package className="h-6 w-6" />
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="pb-2">
                  <CardDescription>Categorías</CardDescription>
                  <CardTitle className="text-3xl">
                    {totalCategories}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-renata-yellow">
                    <ShoppingCart className="h-6 w-6" />
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="pb-2">
                  <CardDescription>Precio Promedio</CardDescription>
                  <CardTitle className="text-3xl">
                    ${averagePrice.toFixed(2)}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-renata-yellow">
                    <DollarSign className="h-6 w-6" />
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="pb-2">
                  <CardDescription>Valor de Inventario</CardDescription>
                  <CardTitle className="text-3xl">
                    ${totalInventoryValue.toFixed(2)}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-renata-yellow">
                    <Users className="h-6 w-6" />
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Recent Products Section */}
            <Card className="mb-10">
              <CardHeader>
                <CardTitle>Productos Recientes</CardTitle>
                <CardDescription>Últimos productos agregados al catálogo</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full border-collapse">
                    <thead>
                      <tr className="border-b">
                        <th className="text-left py-3 px-2">ID</th>
                        <th className="text-left py-3 px-2">Nombre</th>
                        <th className="text-left py-3 px-2">Categoría</th>
                        <th className="text-right py-3 px-2">Precio</th>
                        <th className="text-right py-3 px-2">Stock</th>
                      </tr>
                    </thead>
                    <tbody>
                      {products?.slice(0, 5).map(product => {
                        const category = categories?.find(c => c.id === product.categoryId);
                        return (
                          <tr key={product.id} className="border-b hover:bg-gray-50">
                            <td className="py-3 px-2">{product.id}</td>
                            <td className="py-3 px-2 font-medium">{product.name}</td>
                            <td className="py-3 px-2">{category?.name || 'Sin categoría'}</td>
                            <td className="py-3 px-2 text-right">${product.price.toFixed(2)}</td>
                            <td className="py-3 px-2 text-right">{product.stock}</td>
                          </tr>
                        );
                      })}
                      {(products?.length || 0) === 0 && (
                        <tr>
                          <td colSpan={5} className="py-4 text-center text-gray-500">
                            No hay productos disponibles
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </CardContent>
              <CardFooter>
                <Link href="/admin/products">
                  <Button variant="outline">Ver todos los productos</Button>
                </Link>
              </CardFooter>
            </Card>

            {/* Categories Section */}
            <Card>
              <CardHeader>
                <CardTitle>Categorías</CardTitle>
                <CardDescription>Categorías disponibles en el catálogo</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                  {categories?.map(category => (
                    <div key={category.id} className="border rounded-lg p-4 hover:shadow-md transition-shadow">
                      <h3 className="font-medium">{category.name}</h3>
                      <p className="text-sm text-gray-500 mt-1">{category.description}</p>
                    </div>
                  ))}
                  {(categories?.length || 0) === 0 && (
                    <div className="col-span-full py-4 text-center text-gray-500">
                      No hay categorías disponibles
                    </div>
                  )}
                </div>
              </CardContent>
              <CardFooter>
                <Link href="/admin/categories">
                  <Button variant="outline">Gestionar categorías</Button>
                </Link>
              </CardFooter>
            </Card>
          </>
        )}
      </div>
    </div>
  );
};

export default AdminDashboard;
