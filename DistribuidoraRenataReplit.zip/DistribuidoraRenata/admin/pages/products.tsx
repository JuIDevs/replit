import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Product, Category } from '@shared/schema';
import { Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import ProductTable from '@/components/admin/product-table';
import ProductForm from '@/components/admin/product-form';
import { Link } from 'wouter';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Search, ArrowLeft, Plus } from 'lucide-react';

const AdminProducts = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<string>('');
  const [isCreating, setIsCreating] = useState(false);
  const [editingProductId, setEditingProductId] = useState<number | null>(null);

  const { data: products, isLoading: productsLoading } = useQuery<Product[]>({
    queryKey: ['/api/products'],
  });

  const { data: categories, isLoading: categoriesLoading } = useQuery<Category[]>({
    queryKey: ['/api/categories'],
  });

  // Filter products based on search and category
  const filteredProducts = products?.filter(product => {
    const matchesSearch = product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (product.description && product.description.toLowerCase().includes(searchQuery.toLowerCase()));
    
    const matchesCategory = categoryFilter === 'all' || 
      (categoryFilter === 'null' ? product.categoryId === null : 
       (categoryFilter && product.categoryId === parseInt(categoryFilter)));
    
    return matchesSearch && matchesCategory;
  }) || [];

  const isLoading = productsLoading || categoriesLoading;
  const editingProduct = editingProductId ? products?.find(p => p.id === editingProductId) : null;

  return (
    <div className="py-10 bg-renata-gray min-h-screen">
      <div className="container mx-auto px-4">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-8">
          <div className="flex items-center gap-3">
            <Link href="/admin">
              <Button variant="ghost" size="icon">
                <ArrowLeft className="h-5 w-5" />
              </Button>
            </Link>
            <div>
              <h1 className="text-3xl font-bold text-renata-black">Gestión de Productos</h1>
              <p className="text-renata-dark-gray">Administra el catálogo de productos</p>
            </div>
          </div>
          {!isCreating && !editingProduct && (
            <Button 
              className="mt-4 sm:mt-0 bg-renata-yellow text-renata-black hover:bg-[#ddb012]"
              onClick={() => setIsCreating(true)}
            >
              <Plus className="h-4 w-4 mr-2" />
              Nuevo Producto
            </Button>
          )}
        </div>

        {isCreating || editingProduct ? (
          <ProductForm 
            categories={categories || []} 
            product={editingProduct}
            onCancel={() => {
              setIsCreating(false);
              setEditingProductId(null);
            }}
          />
        ) : (
          <>
            {/* Filters */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
              <div className="relative">
                <Input
                  type="text"
                  placeholder="Buscar productos..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              </div>
              
              <div>
                <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                  <SelectTrigger>
                    <SelectValue placeholder="Filtrar por categoría" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todas las categorías</SelectItem>
                    <SelectItem value="null">Sin categoría</SelectItem>
                    {categories?.map(category => (
                      <SelectItem key={category.id} value={category.id.toString()}>
                        {category.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div className="text-right">
                <Label className="mr-2">Total: {filteredProducts.length} productos</Label>
              </div>
            </div>

            {/* Products Table */}
            {isLoading ? (
              <div className="flex justify-center py-20">
                <Loader2 className="h-8 w-8 animate-spin text-renata-yellow" />
              </div>
            ) : (
              <ProductTable 
                products={filteredProducts} 
                categories={categories || []}
                onEdit={(id) => setEditingProductId(id)}
              />
            )}
          </>
        )}
      </div>
    </div>
  );
};

export default AdminProducts;
