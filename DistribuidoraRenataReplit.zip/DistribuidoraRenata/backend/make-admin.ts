import { db } from './db';
import { users } from '@shared/schema';
import { eq } from 'drizzle-orm';

async function makeUserAdmin(username: string) {
  try {
    // Find the user
    const [user] = await db.select().from(users).where(eq(users.username, username));
    
    if (!user) {
      console.error(`User ${username} not found`);
      return;
    }
    
    // Update user to be admin
    await db
      .update(users)
      .set({ isAdmin: true })
      .where(eq(users.id, user.id));
      
    console.log(`User ${username} is now an admin`);
  } catch (error) {
    console.error('Error:', error);
  }
}

// Get the username from command line arguments
const username = process.argv[2];

if (!username) {
  console.error('Please provide a username');
  process.exit(1);
}

makeUserAdmin(username).then(() => process.exit(0));
