import { db } from './db';
import { categories, products } from '@shared/schema';

async function seedInitialData() {
  try {
    // Check if categories already exist
    const existingCategories = await db.select().from(categories);
    
    if (existingCategories.length === 0) {
      console.log('Seeding categories...');
      const categoryData = [
        {
          name: "Lácteos",
          description: "Quesos, leche, yogurt",
          imageUrl: "https://images.unsplash.com/photo-1590779033100-9f60a05a013d?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80"
        },
        {
          name: "Enlatados",
          description: "Conservas, salsas, legumbres",
          imageUrl: "https://images.unsplash.com/photo-1509440159596-0249088772ff?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80"
        },
        {
          name: "Aceites y Condimentos",
          description: "Aceites, especias, aderezos",
          imageUrl: "https://images.unsplash.com/photo-1625602812206-5ec545ca1231?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80"
        },
        {
          name: "Bebidas",
          description: "Jugos, refrescos, agua",
          imageUrl: "https://images.unsplash.com/photo-1621066875197-4eda31f96564?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80"
        }
      ];
      
      await db.insert(categories).values(categoryData);
      console.log('Categories added!');
    } else {
      console.log('Categories already exist, skipping...');
    }
    
    // Check if products already exist
    const existingProducts = await db.select().from(products);
    
    if (existingProducts.length === 0) {
      console.log('Seeding products...');
      
      // Get categories to link products
      const allCategories = await db.select().from(categories);
      const dairyCategory = allCategories.find(c => c.name === "Lácteos");
      const oilsCategory = allCategories.find(c => c.name === "Aceites y Condimentos");
      const cannedCategory = allCategories.find(c => c.name === "Enlatados");
      const beveragesCategory = allCategories.find(c => c.name === "Bebidas");

      const productData = [
        {
          name: "Leche Entera",
          description: "Leche entera de alta calidad, pasteurizada y homogeneizada. Caja de 12 litros.",
          price: 24.99,
          imageUrl: "https://images.unsplash.com/photo-1559598467-f8b76c8155d0?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80",
          categoryId: dairyCategory?.id,
          stock: 100,
          featured: true,
          tag: "POPULAR"
        },
        {
          name: "Aceite de Oliva Extra Virgen",
          description: "Aceite de oliva extra virgen prensado en frío. Caja con 6 botellas de 1 litro.",
          price: 89.50,
          imageUrl: "https://images.unsplash.com/photo-1625938144755-652e08e359b7?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80",
          categoryId: oilsCategory?.id,
          stock: 50,
          featured: false,
          tag: null
        },
        {
          name: "Atún en Agua",
          description: "Atún en agua de alta calidad. Caja con 24 latas de 170g cada una.",
          price: 68.75,
          imageUrl: "https://images.unsplash.com/photo-1534483509719-3feaee7c30da?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80",
          categoryId: cannedCategory?.id,
          stock: 75,
          featured: true,
          tag: "OFERTA"
        },
        {
          name: "Queso Gouda",
          description: "Queso Gouda en presentación de rueda completa de 4kg. Ideal para restaurantes.",
          price: 120.00,
          imageUrl: "https://images.unsplash.com/photo-1596803244018-908d27aa0bad?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80",
          categoryId: dairyCategory?.id,
          stock: 30,
          featured: false,
          tag: null
        },
        {
          name: "Jugo de Naranja Natural",
          description: "Jugo de naranja 100% natural. Caja con 12 botellas de 1 litro.",
          price: 45.25,
          imageUrl: "https://images.unsplash.com/photo-1600271886742-f049cd451bba?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80",
          categoryId: beveragesCategory?.id,
          stock: 60,
          featured: false,
          tag: null
        },
        {
          name: "Sal Marina Gourmet",
          description: "Sal marina natural. Caja con 12 paquetes de 1kg cada uno.",
          price: 35.80,
          imageUrl: "https://images.unsplash.com/photo-1615485290382-441e4d049cb5?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80",
          categoryId: oilsCategory?.id,
          stock: 45,
          featured: false,
          tag: null
        },
        {
          name: "Frijoles Refritos",
          description: "Frijoles refritos tradicionales. Caja con 24 latas de 440g cada una.",
          price: 52.40,
          imageUrl: "https://images.unsplash.com/photo-1612000529646-f424a2aa1bff?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80",
          categoryId: cannedCategory?.id,
          stock: 40,
          featured: true,
          tag: "NUEVO"
        },
        {
          name: "Agua Mineral",
          description: "Agua mineral premium. Paquete con 24 botellas de 500ml cada una.",
          price: 18.99,
          imageUrl: "https://images.unsplash.com/photo-1563729784474-d77dbb933a9e?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80",
          categoryId: beveragesCategory?.id,
          stock: 120,
          featured: false,
          tag: null
        }
      ];
      
      await db.insert(products).values(productData);
      console.log('Products added!');
    } else {
      console.log('Products already exist, skipping...');
    }
    
    console.log('Data seeding complete!');
  } catch (error) {
    console.error('Error seeding data:', error);
  }
}

seedInitialData().then(() => process.exit(0));
